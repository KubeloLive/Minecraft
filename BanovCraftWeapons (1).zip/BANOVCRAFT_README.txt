BANOVCRAFT 26.2 - 3D WEAPONS + REINFORCED ARMOR


Original 3D weapon models/textures: Nongko Fantasy Weapons pack (user-supplied source pack).

This server variant removes the original custom-name selectors and exposes 84 protected item_model IDs under:

  banovcraft:weapons/<id>


The BanovArmory plugin applies these item_model components only to shop-issued items.

Renaming ordinary vanilla items in an anvil no longer unlocks the custom models.


Reinforced Armor integration:

- Resource pack format: 88.0 for Minecraft Java 26.2.
- Replaces the visual appearance of vanilla armor with Reinforced Armor assets.
- BanovArmory sells the Reinforced Netherite set to every player.
- Full custom 3D geometry uses the included OptiFine CEM files and requires a
  compatible client renderer; armor textures remain included for other clients.
- Shop prices: helmet 3,500,000; chestplate 6,000,000;
  leggings 5,000,000; boots 3,000,000 Banov Money.
