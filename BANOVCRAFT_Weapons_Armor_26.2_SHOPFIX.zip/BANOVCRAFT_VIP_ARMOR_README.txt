BANOVCRAFT 3D WEAPONS + VIP EPIC ARMOR

Obsah:
- pôvodný 3D weapon pack
- Inferno Warlord
- Frost Revenant
- Void Sovereign
- Nature Titan
- Celestial Dragon

Tento ZIP musí byť nastavený ako serverový resource pack.
Použi ho spolu s BanovArmory 2.0.3-COMPAT.
Hráč musí resource pack prijať, inak uvidí vanilla predmety.


SHOPFIX v2.0.4:
- pack obsahuje vsetky armor item modely, equipment definicie a textury
- pouzi tento ZIP, nie povodny BanovCraftWeapons.zip (ten armor subory neobsahuje)
- po zmene vymaz klientsky server-resource-packs cache alebo zmen resource-pack-id
