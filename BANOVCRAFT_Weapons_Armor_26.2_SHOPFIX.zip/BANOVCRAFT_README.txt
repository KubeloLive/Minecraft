BANOVCRAFT protected server integration


Original 3D weapon models/textures: Nongko Fantasy Weapons pack (user-supplied source pack).

This server variant removes the original custom-name selectors and exposes 84 protected item_model IDs under:

  banovcraft:weapons/<id>


The BanovArmory plugin applies these item_model components only to shop-issued items.

Renaming ordinary vanilla items in an anvil no longer unlocks the custom models.
