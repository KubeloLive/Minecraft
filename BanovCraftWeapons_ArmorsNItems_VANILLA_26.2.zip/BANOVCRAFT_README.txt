BANOVCRAFT 26.2 - 3D WEAPONS + VANILLA CUSTOM ARMOR

WEAPONS
- Original 3D weapon models/textures: Nongko Fantasy Weapons pack (user-supplied source pack).
- Protected weapon item_model IDs remain under: banovcraft:weapons/<id>
- Renaming ordinary vanilla items in an anvil does not unlock the BANOVCRAFT weapon models.

ARMOR
- Replaced the previous Reinforced Armor / OptiFine CEM integration.
- Added 9 armor sets from the user-provided ArmorsNItems v2.1 Resource Pack.
- Original ArmorsNItems creator credit: StefanJ2_.
- Included sets: Angel, Cactus, Druid, Emerald, Ender, Fire, Glass, Honey, Soulfire.
- This merged build contains vanilla equipment-model assets only.
- All assets/minecraft/optifine files were intentionally removed.
- No OptiFine, EMF or ETF client mod is required for the included armor assets.

PROTECTED ARMOR ITEM MODELS
Use item_model IDs under:
  banovcraft:armors/<set>_<piece>

Examples:
  banovcraft:armors/angel_helmet
  banovcraft:armors/ender_chestplate
  banovcraft:armors/soulfire_leggings
  banovcraft:armors/emerald_boots

IMPORTANT
The resource pack only supplies visuals. The server plugin or command that creates the armor
must assign both the matching item_model and matching vanilla equipment asset ID.
See ARMOR_ASSET_IDS.txt for the exact IDs.

REDISTRIBUTION
Armor assets came from the user-provided ArmorsNItems v2.1 pack. Keep creator credit and
check the original author's redistribution/licensing terms before publishing this merged ZIP.

PREMIUM RANK BADGES
- Added graphical BANOVCRAFT rank badges to the default Minecraft font.
- Private-use glyphs used by the server plugins:
  E001 HRAC, E002 VIP, E003 VIP+, E004 LEGEND, E005 MODERATOR, E006 ADMIN, E007 MAJITEL.
- These badge assets are required for BanovPermisie PREMIUM BADGES / BanovHUD PREMIUM BADGES.

